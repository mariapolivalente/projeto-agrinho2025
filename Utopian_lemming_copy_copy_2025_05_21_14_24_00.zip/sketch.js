let player;
let resources = [];
let resourceCount = 0;

function setup() {
  createCanvas(800, 600);
  player = new Player(width / 2, height / 2);
  noStroke();

  // Gerar recursos (árvores) aleatórios
  for (let i = 0; i < 10; i++) {
    resources.push(new Resource(random(width), random(height)));
  }
}

function draw() {
  background(220);

  // Mostra o campo e a cidade
  fill(150, 255, 150);
  rect(0, 0, width / 2, height); // Campo

  fill(255, 150, 150);
  rect(width / 2, 0, width / 2, height); // Cidade

  // Mostra as árvores
  for (let resource of resources) {
    resource.display();
  }

  // Mostra o jogador
  player.move();
  player.display();

  // Verifica coleta de recursos
  for (let i = resources.length - 1; i >= 0; i--) {
    if (player.collect(resources[i])) {
      resources.splice(i, 1);
      resourceCount++;
    }
  }

  // Mensagem na tela
  fill(0);
  textSize(24);
  text(`Árvores Coletadas: ${resourceCount}`, 10, 30);
}

class Player {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.size = 30;
  }

  display() {
    fill(100, 100, 250);
    ellipse(this.position.x, this.position.y, this.size); // Jogador
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.position.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.position.x += 5;
    }
    if (keyIsDown(UP_ARROW)) {
      this.position.y -= 5;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.position.y += 5;
    }

    // Limita o movimento dentro da tela
    this.position.x = constrain(this.position.x, 0, width);
    this.position.y = constrain(this.position.y, 0, height);
  }

  collect(resource) {
    let d = dist(this.position.x, this.position.y, resource.position.x, resource.position.y);
    return d < this.size / 2 + resource.size / 2;
  }
}

class Resource {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.size = 40; // Tamanho da árvore
  }

  display() {
    // Desenha uma árvore simples
    fill(34, 139, 34); // Cor verde
    triangle(this.position.x, this.position.y - this.size / 2,
             this.position.x - this.size / 2, this.position.y + this.size / 2,
             this.position.x + this.size / 2, this.position.y + this.size / 2);
    
    fill(139, 69, 19); // Cor marrom para o tronco
    rect(this.position.x - this.size / 10, this.position.y, this.size / 5, this.size / 2);
  }
}